Project 0 CIS 520 README File

By: Brian Cain
==============================

Files changed

-tests.c

I had to add a single line of code so that tests.c would know which test will run when I added "alarm-mucho".

-test.h

I had to add an "extern" term for the test function of my name test_alarm_mucho so that pintos would know what I was calling

-alarm-mucho.ck

I had to program this file which I based off of alarm-many, and then I added it to the tests/threads folder.

-alarm-wait.c

This is the controller file. I had to add my own function alarm-mucho so that it has 5 threads and generates 21 alarms.
